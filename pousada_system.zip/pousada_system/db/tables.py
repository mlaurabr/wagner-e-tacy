from db.connection import get_db_connection

def criar_tabelas():
    """Criação das tabelas no banco de dados."""
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quartos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            numero VARCHAR(10) UNIQUE NOT NULL,
            camas INT NOT NULL,
            banheiros INT NOT NULL,
            ar_condicionado VARCHAR(10),
            disponivel BOOLEAN DEFAULT TRUE
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS hospedes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            idade INT NOT NULL,
            cpf VARCHAR(15) UNIQUE NOT NULL,
            contato VARCHAR(20),
            usuario_id INT,
            quarto_id INT,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
            FOREIGN KEY (quarto_id) REFERENCES quartos(id)
        )
    """)

    conn.commit()
    cursor.close()
    conn.close()
