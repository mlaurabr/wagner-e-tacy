import mysql.connector

db_config = {
    "host": "localhost",
    "user": "root",  
    "password": "sua_senha",  
    "database": "pousada"
}

def get_db_connection():
    """Estabelece conexão com o banco de dados."""
    return mysql.connector.connect(**db_config)
