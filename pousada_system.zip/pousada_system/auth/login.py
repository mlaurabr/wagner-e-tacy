from db.connection import get_db_connection
from auth.hashing import check_password
from services.menu import inicio

def login():
    """Realiza a autenticação do usuário."""
    print("\n============= SISTEMA DA POUSADA =============")
    usuario = input("Digite seu nome de usuário: ")
    senha = input("Digite sua senha: ")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = "SELECT * FROM usuarios WHERE username = %s"
    cursor.execute(query, (usuario,))
    user = cursor.fetchone()

    if user and check_password(senha, user['password']):
        print("Login bem-sucedido!")
        inicio(user['id'])  
    else:
        print("Usuário ou senha incorretos.")

    cursor.close()
    conn.close()
