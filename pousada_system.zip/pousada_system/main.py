from db.tables import criar_tabelas
from auth.login import login
from services.menu import exibir_menu_principal

def main():
    """Inicia o sistema da pousada."""
    criar_tabelas()  
    user_id = login()  
    if user_id:
        exibir_menu_principal(user_id) 

if __name__ == "__main__":
    main()
