from utils.screen import limpar_tela
from services.cadastro import cadastrar_hospede, cadastrar_quarto
from services.consultas import listar_hospedes_por_usuario, buscar_quartos_por_caracteristica

def exibir_menu_principal(user_id):
    """
    Exibe o menu principal para o usuário.
    :param user_id: ID do usuário autenticado
    """
    while True:
        limpar_tela()
        print("===== Sistema de Gerenciamento de Pousada =====")
        print("1. Cadastrar Hóspede")
        print("2. Cadastrar Quarto")
        print("3. Listar Hóspedes")
        print("4. Buscar Quartos")
        print("0. Sair")
        
        escolha = input("\nEscolha uma opção: ")

        if escolha == "1":
            cadastrar_hospede(user_id)
        elif escolha == "2":
            cadastrar_quarto()
        elif escolha == "3":
            listar_hospedes_por_usuario(user_id)
        elif escolha == "4":
            termo = input("Digite uma característica (número/quarto): ")
            buscar_quartos_por_caracteristica(termo)
        elif escolha == "0":
            print("Saindo do sistema...")
            break
        else:
            print("Opção inválida. Tente novamente.")
        
        input("\nPressione Enter para continuar...")
