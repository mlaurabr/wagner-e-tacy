from db.connection import get_db_connection

def listar_hospedes_por_usuario(user_id):
    """Lista hóspedes cadastrados pelo usuário logado."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = """
        SELECT h.nome, h.idade, h.cpf, q.numero AS quarto
        FROM hospedes h
        LEFT JOIN quartos q ON h.quarto_id = q.id
        WHERE h.usuario_id = %s
        ORDER BY h.nome ASC
    """
    cursor.execute(query, (user_id,))
    hospedes = cursor.fetchall()

    print("\nHóspedes cadastrados:")
    for hospede in hospedes:
        print(f"Nome: {hospede['nome']}, Idade: {hospede['idade']}, CPF: {hospede['cpf']}, Quarto: {hospede['quarto']}")

    cursor.close()
    conn.close()

def buscar_quartos_por_caracteristica(caracteristica):
    """Busca quartos com base em uma característica."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    query = """
        SELECT * FROM quartos
        WHERE numero LIKE %s OR ar_condicionado LIKE %s
    """
    like_param = f"%{caracteristica}%"
    cursor.execute(query, (like_param, like_param))
    quartos = cursor.fetchall()

    print("\nQuartos encontrados:")
    for quarto in quartos:
        print(f"ID: {quarto['id']}, Número: {quarto['numero']}, Camas: {quarto['camas']}, Banheiros: {quarto['banheiros']}, Ar: {quarto['ar_condicionado']}")

    cursor.close()
    conn.close()
