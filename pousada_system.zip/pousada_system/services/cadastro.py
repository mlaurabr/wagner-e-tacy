from db.connection import get_db_connection

def cadastrar_hospede(user_id):
    """Cadastra um novo hóspede."""
    print("Informações do Hóspede:")
    nome = input("Nome: ")
    idade = input("Idade: ")
    cpf = input("CPF: ")
    contato = input("Contato: ")

    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO hospedes (nome, idade, cpf, contato, usuario_id)
        VALUES (%s, %s, %s, %s, %s)
    """
    cursor.execute(query, (nome, idade, cpf, contato, user_id))
    conn.commit()

    print("Hóspede cadastrado com sucesso!")
    cursor.close()
    conn.close()

def cadastrar_quarto():
    """Cadastra um novo quarto."""
    print("Informações do Quarto:")
    numero = input("Número do Quarto: ")
    camas = input("Quantidade de Camas: ")
    banheiros = input("Quantidade de Banheiros: ")
    ar_condicionado = input("Ar Condicionado (Sim/Não): ")

    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        INSERT INTO quartos (numero, camas, banheiros, ar
