Sistema de Gerenciamento de Pousada
Este é um sistema simples para gerenciar hóspedes e quartos de uma pousada, desenvolvido em Python com integração ao banco de dados MySQL. O sistema permite autenticação de usuários, cadastro de hóspedes e quartos, além de realizar consultas com segurança e modularidade.

Funcionalidades
Autenticação de Usuário:

Login com validação de credenciais.
Senhas armazenadas com hash (utilizando bcrypt).
Gerenciamento de Dados:

Cadastro:
Hóspedes (vinculados ao usuário logado).
Quartos da pousada.
Consultas:
Listagem de hóspedes cadastrados por um usuário específico.
Busca de quartos por características utilizando SQL LIKE.
Segurança:

Hash de senhas para maior proteção.
Prevenção contra SQL Injection.
Garantia de que usuários só possam acessar seus próprios registros.
Modularidade:

Código organizado em módulos para facilitar a manutenção e escalabilidade.
Estrutura do Projeto
plaintext


pousada_system/
│
├── main.py                  # Arquivo principal
├── db/                      # Diretório para configuração e funções do banco
│   ├── connection.py        # Configuração do banco
│   ├── tables.py            # Criação de tabelas
│
├── auth/                    # Diretório para autenticação
│   ├── login.py             # Login e funções relacionadas
│   ├── hashing.py           # Hash e verificação de senhas
│
├── services/                # Funcionalidades principais (CRUD, consultas)
│   ├── cadastro.py          # Cadastro de hóspedes e quartos
│   ├── consultas.py         # Consultas de dados
│   ├── menu.py              # Menu principal do sistema
│
└── utils/                   # Utilitários gerais
    ├── screen.py            # Funções utilitárias (limpar tela, etc.)


Requisitos
Python 3.8+
MySQL
Bibliotecas Python:
mysql-connector-python
bcrypt

Crie um banco de dados MySQL:
CREATE DATABASE pousada_system;

Configure a conexão com o banco de dados:

Edite o arquivo db/connection.py e insira as credenciais do MySQL:
python
config = {
    'user': 'seu_usuario',
    'password': 'sua_senha',
    'host': 'localhost',
    'database': 'pousada_system'
}



Instale as dependências do Python:
pip install mysql-connector-python bcrypt

Execute o sistema:
python main.py

Como Usar
Login:

Ao iniciar, o sistema solicitará as credenciais. Se for o primeiro uso, você pode se cadastrar.
Menu Principal:

Cadastrar Hóspede: Adicione novos hóspedes associados ao usuário logado.
Cadastrar Quarto: Registre quartos disponíveis na pousada.
Listar Hóspedes: Visualize os hóspedes que você cadastrou.
Buscar Quartos: Encontre quartos baseando-se em características específicas.
Sair:

Finaliza a execução do sistema.
Consultas SQL Implementadas
INNER JOIN: Para combinar dados entre usuários e hóspedes.
LIKE: Para buscar quartos por características específicas.
ORDER BY: Para organizar os resultados das consultas.